package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.InteractionUtil;
import com.firebow.util.PlacementCalc;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;
        if (mc.player == null || mc.interactionManager == null) return;
        if (self.getVelocity().lengthSquared() < 0.0001) return;

        // Tên bay quá 40 tick → bỏ qua (fix "bắn xa lại gần vẫn cart")
        if (((Entity) self).age > 40) return;

        int entityId = self.getId();
        if (rt.isDuplicateArrow(entityId)) return;

        Vec3d arrowPos = self.getPos();
        Vec3d velocity = self.getVelocity();
        World world    = self.getWorld();

        // Thử dùng vị trí precomputed từ bow release (nhanh hơn)
        // Nếu không có thì predict từ trajectory hiện tại (fallback)
        BlockPos precomputed = rt.getAndClearPrecomputed();
        BlockPos railPos;

        if (precomputed != null && !rt.wasRecentlyPlaced(precomputed)
                && InteractionUtil.inReach(mc.player, precomputed)
                && mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(precomputed)) >= 1.0) {
            // Dùng precomputed — trigger ngay tick đầu tiên tên xuất hiện
            railPos = precomputed;
        } else {
            // Fallback: predict từ trajectory
            railPos = PlacementCalc.predictLandingRailPos(world, arrowPos, velocity);
            if (railPos == null) return;
            if (!InteractionUtil.inReach(mc.player, railPos)) return;
            if (rt.wasRecentlyPlaced(railPos)) return;
            if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.0) return;

            int ticksLeft = estimateTicksToLand(arrowPos, velocity, railPos);
            if (ticksLeft > 20) return;
        }

        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        // Đặt Rail — arrow đang bay, player không thể draw cung → không bao giờ interrupt
        int savedSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = target.railSlot.slot;
        InteractionUtil.placeBelow(mc, railPos);
        mc.player.getInventory().selectedSlot = savedSlot;

        long ping = getPing(mc);
        int cartDelay = ping > 200 ? 3 : ping > 100 ? 2 : 1;
        rt.acceptArrow(entityId, railPos, cartDelay);
    }

    private int estimateTicksToLand(Vec3d pos, Vec3d vel, BlockPos target) {
        double x = pos.x, y = pos.y, z = pos.z;
        double vx = vel.x, vy = vel.y, vz = vel.z;
        Vec3d t = Vec3d.ofCenter(target);
        for (int i = 0; i < 60; i++) {
            vy -= 0.05; vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;
            if (Math.sqrt((x-t.x)*(x-t.x)+(y-t.y)*(y-t.y)+(z-t.z)*(z-t.z)) < 1.5)
                return i;
        }
        return 60;
    }

    private long getPing(MinecraftClient mc) {
        try {
            if (mc.getNetworkHandler() == null || mc.player == null) return 50L;
            var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return e != null ? e.getLatency() : 50L;
        } catch (Exception ex) { return 50L; }
    }

    private boolean isOwnArrow(PersistentProjectileEntity arrow, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = arrow.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
