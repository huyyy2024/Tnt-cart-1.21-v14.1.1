package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Tiện ích đặt block — tách riêng khỏi Runtime.
 * Không xoay camera, không side effect ngoài đặt block.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    /**
     * Đặt cart lên rail tại pos.
     * Hit vector 0.1 trên mặt rail — đúng với v4 gốc.
     */
    public static boolean placeOnTop(MinecraftClient mc, BlockPos pos) {
        return place(mc, pos, Direction.UP,
            Vec3d.ofCenter(pos).add(0, 0.1, 0));
    }

    /**
     * Đặt rail tại pos bằng cách click mặt trên của block phía dưới.
     * Hit vector 0.5 dưới tâm pos — đúng với v4 gốc.
     */
    public static boolean placeBelow(MinecraftClient mc, BlockPos pos) {
        return place(mc, pos.down(), Direction.UP,
            Vec3d.ofCenter(pos).add(0, -0.5, 0));
    }

    private static boolean place(MinecraftClient mc, BlockPos hitPos,
                                  Direction face, Vec3d hitVec) {
        if (mc.player == null || mc.interactionManager == null) return false;
        try {
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(hitVec, face, hitPos, false));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Kiểm tra player có trong tầm đặt block không (max 4.5 block). */
    public static boolean inReach(ClientPlayerEntity player, BlockPos pos) {
        Vec3d eyes = player.getEyePos();
        Vec3d center = Vec3d.ofCenter(pos);
        return eyes.squaredDistanceTo(center) <= 4.5 * 4.5;
    }
}
